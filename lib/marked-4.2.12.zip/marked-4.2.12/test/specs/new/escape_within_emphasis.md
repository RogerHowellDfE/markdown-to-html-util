**strong text\[**\]

**strong text\\\[**\]

_em\[pha\]\(sis\)_

_\\_
