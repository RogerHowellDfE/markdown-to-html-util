This fails in markdown.pl and upskirt:

* hello
  > world
