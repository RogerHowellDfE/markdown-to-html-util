A paragraph
```A
Here is code in
backtick fences
```

B paragraph
~~~B
Here is code in
tilde fences
~~~

C paragraph
~~~`C~
Alternative
tilde fences
~~~

D paragraph
```~D`
Invalid use of
backtick fences
```

This will be read as
part of a codeblock
that ends with the file
