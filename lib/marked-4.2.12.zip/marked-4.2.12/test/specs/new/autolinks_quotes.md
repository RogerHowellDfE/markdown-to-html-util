"https://www.example.com?test=quote-in-"-url"

'https://www.example.com?test=quote-in-'-url'
