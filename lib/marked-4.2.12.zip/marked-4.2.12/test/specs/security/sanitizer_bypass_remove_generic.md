---
sanitize: true
sanitizer: () => ''
---
<a>a2<a2t>a2</a> b <c>c</c> d
# ![text](URL)